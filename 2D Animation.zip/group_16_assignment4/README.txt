Step 1: Open the "group_16_assignment4.pde" file.
Step 2: Run the code, the animation should pop up and play.